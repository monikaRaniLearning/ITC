'use strict';

var UtilityMethods = function() {

};

UtilityMethods.prototype = {
    using: function (name, values,func, bound) {

       //console.log(name);
        //console.log(values);

        for(var i = 0, count = values.length;i<count;i++) {


            values[i] = [values[i]];
        }

        func.apply(bound, values[i]);



    }
}

module.exports = UtilityMethods;