'Use strict'
import {browser,protractor,by,element,ElementFinder,By,ElementArrayFinder} from 'protractor';
var loginURL = '';
var logout = '';
var evn = browser.params.env;

export class MyStorePage {
    searchBox:ElementFinder  = element(by.name('search_query'));
    searchHighlited:ElementFinder  = element(by.xpath("//h1[@class='page-heading  product-listing']/span[@class='lighter']"));
    productItemCount:ElementFinder  = element(by.xpath("(//div[@class='product-count'])[1]"));
    addToCart:ElementArrayFinder  = element.all(by.xpath("(//span[text()='Add to cart'])[1]"));
    cartSucessfulMsg:ElementFinder = element(by.xpath("//div[@id='layer_cart']//i[@class='icon-ok']"));
    shoppingCartItemNumber:ElementFinder = element(by.xpath('//*[@class="shopping_cart"]//span[@class="ajax_cart_quantity"]'));
    
    constructor() {

        switch(evn) {
            case "QA" :
                 loginURL = "http://automationpractice.com/";
                 logout = "http://localhost:6020";
                 break;
            case "test" :
                 loginURL = "http://localhost:6020";
                 logout = "http://localhost:6020";
                 break;
        }

        browser.ignoreSynchronization = true;
        browser.get(loginURL);
        browser.driver.manage().window().maximize();
    }
}