import {browser, protractor, by, element, ElementArrayFinder, ElementFinder} from 'protractor';
import * as request from "request";
'use strict';
import { MyStorePage } from '../pages/myStore.page';
import { myStoreParam } from '../params/myStoreParam';
var UtilityMethods = require('../utility/utilityMethods.js')
var page = new MyStorePage();
var param = new myStoreParam();
var BaseMethods = new UtilityMethods();
var EC = protractor.ExpectedConditions;
describe('Test My Store',function(){

beforeAll(function(){
  
});

afterAll(function(){

});

//********************************************************************************************************************************* */

describe('verify My Store', function(){
beforeAll(function(){
   page.searchBox.sendKeys("t-shirt");
});


it('verify Searched Highlight', function(){
expect<any>(page.searchHighlited.getText()).toEqual('t-shirt','Failed Test - not showing searchHighlited item ')
})

it('verify Searched  item count', function(){
    expect<any>((page.productItemCount.getText()).trim()).toEqual('Showing 1 - 1 of 1 item','Failed Test - not showing productItemCount  ')
    })

})
//********************************************************************************************************************************* */
//********************************************************************************************************************************* */


BaseMethods.using("test params", myStoreParam.shoppingCart,function(value){

    var title = '';
    var testParam = value;
    for(var v in value)
        {
            if(title) title += ', ';
            title += v + ': ' +value[v];
        }
})
describe('verify shopping cart', function(){
    beforeAll(function(){
       page.searchBox.sendKeys(testParam.searchBoxValue);
       page.addToCart.get(1).click();
    });
    
    
    it('verify shopping cart sucessful message', function(){
    expect<any>(page.cartSucessfulMsg.getText()).toEqual(testParam.expectedMessage,'Failed Test - not showing successfully message')
    })

    it('verify shopping cart item number', function(){
        expect<any>(page.shoppingCartItemNumber.getText()).toEqual(testParam.expectedcartItemNumber,'Failed Test - not showing item number added to cart')
        }) 
    })
//********************************************************************************************************************

})