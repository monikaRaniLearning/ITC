
import { ProtractorBrowser, Config, browser} from 'protractor';
let Jasmine2HtmlReporter = require('protractor-jasmine2-html-reporter');

var path = require('path');

var reporter = new Jasmine2HtmlReporter({
  savePath: './target/reports/',
  screenshotsFolder: 'screenshots',
  takeScreenshots:true,
  takeScreenshotsOnlyOnFailures: true,
});

export let config: Config = {
  suites:{
  myStore:'steps/myStore.js',
  
  },


capabilities: {
  
  'browserName': 'chrome',
  //  'chromeOptions': {
  //   'args': ['disable-infobars=true']
    
  //  }

  // "chromeOptions": {
  //   binary: 'C:/Users/manojc/AppData/Roaming/npm/node_modules/webdriver-manager/selenium/chromedriver_win32/chromedriver',
  // }
},
directConnect:true,
// baseUrl: 'http://localhost:4200/wd/hub',
seleniumAddress: 'http://localhost:4444/wd/hub',
specs:['specs/*_spec.js'],
framework: 'jasmine',
params:{
  env:"QA",
 

},
rootElement: 'html',
onPrepare: () => {

jasmine.getEnv().addReporter(reporter);
  var jasmineReporters = require('jasmine-reporters');
  var junitReporter = new jasmineReporters.JUnitXmlReporter({
   //setup the output path for junite reports
   savePath: './target/reports/',
   filePrefix: 'xmloutput'
  });
  jasmine.getEnv().addReporter(junitReporter);
  browser.driver.manage().window().maximize();
  browser.manage().timeouts().pageLoadTimeout(40000);
},

  allScriptsTimeout:200000
}
