export class myStoreParam {

    static shoppingCart =[
{testCase: 1,searchBoxvalue: 'Printed Chiffon Dress',expectedMessage:'Product successfully added to your shopping cart',expectedcartItemNumber: 1},
{testCase: 2,searchBoxvalue: 'Printed Chiffon',expectedMessage:'Product successfully added to your shopping cart',expectedcartItemNumber: 2}
    ];

}